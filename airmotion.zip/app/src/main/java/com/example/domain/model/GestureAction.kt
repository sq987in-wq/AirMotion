package com.example.domain.model

enum class HandGesture {
    SWIPE_UP,
    SWIPE_DOWN,
    WAVE
}

enum class ActionTrigger(val label: String) {
    SCROLL_UP("Scroll Up"),
    SCROLL_DOWN("Scroll Down"),
    PLAY_PAUSE("Play/Pause"),
    ANSWER_CALL("Answer Call"),
    NONE("None");

    companion object {
        fun fromLabel(label: String): ActionTrigger {
            return values().find { it.label.equals(label, ignoreCase = true) } ?: NONE
        }
    }
}
