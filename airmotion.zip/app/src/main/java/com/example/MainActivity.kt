package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.presentation.screens.DashboardScreen
import com.example.presentation.screens.OnboardingScreen
import com.example.presentation.screens.SplashScreen
import com.example.presentation.viewmodel.DashboardViewModel
import com.example.service.AirMotionAccessibilityService
import com.example.ui.theme.MyApplicationTheme

enum class AppNavigation {
    SPLASH,
    ONBOARDING,
    DASHBOARD
}

class MainActivity : ComponentActivity() {

    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                var currentNavigationState by remember { mutableStateOf(AppNavigation.SPLASH) }

                Scaffold(modifier = Modifier.fillMaxSize()) { _ ->
                    // Smooth visual state transition crossfade
                    Crossfade(
                        targetState = currentNavigationState,
                        label = "AppNavigationTransition"
                    ) { state ->
                        when (state) {
                            AppNavigation.SPLASH -> {
                                SplashScreen(
                                    onNextScreen = {
                                        val hasCamera = ContextCompat.checkSelfPermission(
                                            this@MainActivity,
                                            Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED
                                        
                                        val hasPhoneState = ContextCompat.checkSelfPermission(
                                            this@MainActivity,
                                            Manifest.permission.READ_PHONE_STATE
                                        ) == PackageManager.PERMISSION_GRANTED &&
                                        ContextCompat.checkSelfPermission(
                                            this@MainActivity,
                                            Manifest.permission.ANSWER_PHONE_CALLS
                                        ) == PackageManager.PERMISSION_GRANTED

                                        val isAccessibilityActive = AirMotionAccessibilityService.isRunning()

                                        currentNavigationState = if (hasCamera && hasPhoneState && isAccessibilityActive) {
                                            AppNavigation.DASHBOARD
                                        } else {
                                            AppNavigation.ONBOARDING
                                        }
                                    }
                                )
                            }
                            AppNavigation.ONBOARDING -> {
                                OnboardingScreen(
                                    onComplete = {
                                        currentNavigationState = AppNavigation.DASHBOARD
                                    }
                                )
                            }
                            AppNavigation.DASHBOARD -> {
                                DashboardScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Force state refresh in ViewModel to recognize background Accessibility activation
        viewModel.checkAccessibilityServiceStatus()
    }
}
