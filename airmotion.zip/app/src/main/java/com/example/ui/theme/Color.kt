package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium AirMotion Color Palette
val DeepIndigoBackground = Color(0xFF1A1B2F) // #1A1B2F from Sophisticated Dark
val DeepIndigoSurface = Color(0xFF121323)
val CardBackground = Color(0xFF22233B)       // Rich deep layered card background
val ElectricCyan = Color(0xFF00E5FF)         // Active cyber cyan accent
val CoralPink = Color(0xFFFF2E93)            // Hot pink alarm/warning accent
val TextActive = Color(0xFFF1F5F9)           // slate-100
val TextSecondary = Color(0xFF94A3B8)        // slate-400
val GrayBorder = Color(0x0DFFFFFF)           // border-white/5 for subtle framing
val SuccessGreen = Color(0xFF00E676)
val ShadowDark = Color(0x3D00E5FF)           // cyan shadow accent
val TranslucentWhiteBg = Color(0x0DFFFFFF)   // bg-white/5
val TranslucentWhiteBgActive = Color(0x1AFFFFFF) // bg-white/10
