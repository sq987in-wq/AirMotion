package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val AirMotionDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = DeepIndigoBackground,
    secondary = ElectricCyan,
    onSecondary = DeepIndigoBackground,
    tertiary = CoralPink,
    onTertiary = TextActive,
    background = DeepIndigoBackground,
    onBackground = TextActive,
    surface = CardBackground,
    onSurface = TextActive,
    surfaceVariant = DeepIndigoSurface,
    onSurfaceVariant = TextSecondary,
    outline = GrayBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // default to premium dark mode always
    dynamicColor: Boolean = false, // Force custom themes rather than dynamic system hues for brand consistency
    content: @Composable () -> Unit,
) {
    val colorScheme = AirMotionDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
