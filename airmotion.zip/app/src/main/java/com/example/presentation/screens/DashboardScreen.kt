package com.example.presentation.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.domain.model.ActionTrigger
import com.example.domain.model.HandGesture
import com.example.presentation.viewmodel.DashboardViewModel
import com.example.service.AirMotionAccessibilityService
import com.example.service.GestureAnalyzer
import com.example.ui.theme.DeepIndigoBackground
import com.example.ui.theme.TranslucentWhiteBg
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.CoralPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.GrayBorder
import java.util.concurrent.Executors

@Composable
fun PulsingStatusDot(color: Color, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_dot_trans")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_dot_alpha"
    )
    Box(
        modifier = modifier
            .size(8.dp)
            .clip(CircleShape)
            .alpha(alpha)
            .background(color)
    )
}

@Composable
fun DashboardScreen(viewModel: DashboardViewModel) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Preferences states from viewmodel
    val isServiceEnabled by viewModel.isServiceEnabled.collectAsState()
    val sensitivity by viewModel.sensitivity.collectAsState()
    val cooldownDelay by viewModel.cooldownDelay.collectAsState()
    val showPreview by viewModel.showPreview.collectAsState()
    val previewOpacity by viewModel.previewOpacity.collectAsState()

    val swipeUpMapping by viewModel.swipeUpAction.collectAsState()
    val swipeDownMapping by viewModel.swipeDownAction.collectAsState()
    val waveMapping by viewModel.waveAction.collectAsState()

    // Metrics states
    val currentFps by viewModel.fps.collectAsState()
    val isLowLight by viewModel.isLowLight.collectAsState()
    val averageLuminance by viewModel.averageLuminance.collectAsState()
    val lastGesture by viewModel.lastDetectedGesture.collectAsState()
    val isAccessibilityConnected by viewModel.isAccessibilityServiceConnected.collectAsState()

    // Recheck status on resume
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.checkAccessibilityServiceStatus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigoBackground)
            .testTag("dashboard_screen"),
        containerColor = DeepIndigoBackground,
        bottomBar = {
            Column {
                HorizontalDivider(color = TranslucentWhiteBg, thickness = 1.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F1020)) // slate-900/50 backdrop
                        .navigationBarsPadding()
                        .padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Main button active state
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Main controller tab active",
                            tint = ElectricCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "MAIN",
                            color = ElectricCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // History button inactive
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .alpha(0.5f)
                            .clickable { }
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History tab",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "HISTORY",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // Guide button inactive
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .alpha(0.5f)
                            .clickable { }
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Guide directions",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "GUIDE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(bottom = 24.dp)
        ) {
            // Refined Header Bar with Glowing Logo, Blinking active dot
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo box with gradient and glowing shadow
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                Brush.linearGradient(listOf(ElectricCyan, CoralPink)),
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gesture,
                            contentDescription = "AirMotion dynamic symbol",
                            tint = DeepIndigoBackground,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "AirMotion",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                fontSize = 20.sp
                            ),
                            modifier = Modifier.testTag("header_title")
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            val isActive = isAccessibilityConnected && isServiceEnabled
                            PulsingStatusDot(
                                color = if (isActive) ElectricCyan else CoralPink
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isActive) "ACTIVE" else "STAND-BY",
                                color = if (isActive) ElectricCyan.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.4f),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.5.sp
                                )
                            )
                        }
                    }
                }

                // Subtly framed settings button
                IconButton(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open settings", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .background(TranslucentWhiteBg, RoundedCornerShape(14.dp))
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Accessibility settings shortcut",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Real-Time Action Flash Panel (Flashes when gesture is registered)
            AnimatedVisibility(
                visible = lastGesture != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, ElectricCyan, RoundedCornerShape(16.dp))
                        .testTag("gesture_flash_banner"),
                    colors = CardDefaults.cardColors(containerColor = ElectricCyan.copy(alpha = 0.12f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gesture,
                            contentDescription = "Detected",
                            tint = ElectricCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Gesture Detected: ${lastGesture ?: ""}",
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            // 1. Master Capture Toggle Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp))
                    .testTag("detection_toggle_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BackHand,
                                contentDescription = "Active state status handle",
                                tint = if (isServiceEnabled) ElectricCyan else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gesture Detection",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isServiceEnabled) "Accessibility service running" else "Detection suspended",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Switch(
                        checked = isServiceEnabled,
                        onCheckedChange = { viewModel.setServiceEnabled(it) },
                        modifier = Modifier.testTag("gesture_switch")
                    )
                }
            }

            // 2. Camera Preview Surface Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp))
                    .testTag("camera_preview_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Preview",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Conceal Face",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            IconButton(
                                onClick = { viewModel.setShowPreview(!showPreview) },
                                modifier = Modifier.testTag("preview_toggle")
                            ) {
                                Icon(
                                    imageVector = if (showPreview) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle physical camera exposure visibility",
                                    tint = if (showPreview) ElectricCyan else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Camera View with beautiful interactive overlays
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F1020))
                            .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isServiceEnabled) {
                            if (showPreview) {
                                // Camera preview layer
                                CameraPreviewContainer(
                                    viewModel = viewModel,
                                    opacity = previewOpacity,
                                    sensitivity = sensitivity,
                                    cooldown = cooldownDelay
                                )
                            } else {
                                // Styled Silhouette privacy model (hidden preview, still processes)
                                SilhouettePrivacyView(fps = currentFps)
                            }

                            // Sophisticated Dark Overlay hud (REC indicator bar & hud controls)
                            // Top Left HUD Overlay
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(12.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(CoralPink)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "REC",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ISO 400 • ${currentFps} FPS",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Bottom Right Target Overlay
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(12.dp)
                                    .size(36.dp)
                                    .border(1.5.dp, ElectricCyan, CircleShape)
                                    .background(ElectricCyan.copy(alpha = 0.08f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(ElectricCyan)
                                )
                            }
                        } else {
                            // Offline stand-by layout
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VideocamOff,
                                    contentDescription = "Camera disconnected",
                                    tint = CoralPink,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Camera Core Idle",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Turn gesture detection ON to launch the engine",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    if (isServiceEnabled && showPreview) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Opacity,
                                contentDescription = "Opacity icon",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Preview Opacity",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Slider(
                                value = previewOpacity,
                                onValueChange = { viewModel.setPreviewOpacity(it) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("opacity_slider"),
                                valueRange = 0.05f..1.0f,
                                colors = SliderDefaults.colors(
                                    activeTrackColor = ElectricCyan,
                                    thumbColor = ElectricCyan
                                )
                            )
                        }
                    }
                }
            }

            // 3. Quick Stats / Recent Trigger Log widget (styled from Sophisticated Dark design)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RECENT TRIGGER",
                            color = TextSecondary,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = if (lastGesture != null) "Active Log" else "Idle State",
                            color = if (lastGesture != null) CoralPink else TextSecondary.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (lastGesture != null) CoralPink.copy(alpha = 0.12f) else TranslucentWhiteBg
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (lastGesture != null) Icons.Default.Gesture else Icons.Default.RadioButtonChecked,
                                contentDescription = "Activity signal",
                                tint = if (lastGesture != null) CoralPink else TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = if (lastGesture != null) "$lastGesture Registered" else "No Gesture Detected",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (lastGesture != null) "Action: Simulate global key swipe event" else "Standing by for gesture motion...",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            // 4. Bento Box Slider Grids (Sensitivity & Cooldown side by side)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .testTag("sliders_card"),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Sensitivity Bento Block
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(150.dp)
                        .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sensors,
                                contentDescription = "Sensors icon",
                                tint = ElectricCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "SENSITIVITY",
                                color = TextSecondary,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Text(
                                    text = "$sensitivity",
                                    color = ElectricCyan,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Light
                                )
                                Text(
                                    text = "%",
                                    color = ElectricCyan,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(bottom = 3.dp, start = 1.dp)
                                )
                            }

                            Slider(
                                value = sensitivity.toFloat(),
                                onValueChange = { viewModel.setSensitivity(it.toInt()) },
                                valueRange = 1f..100f,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .height(24.dp)
                                    .testTag("sensitivity_slider"),
                                colors = SliderDefaults.colors(
                                    activeTrackColor = ElectricCyan,
                                    thumbColor = ElectricCyan,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                )
                            )
                        }
                    }
                }

                // Cooldown Bento Block
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(150.dp)
                        .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer icon",
                                tint = CoralPink,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "COOLDOWN",
                                color = TextSecondary,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Text(
                                    text = "$cooldownDelay",
                                    color = CoralPink,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Light
                                )
                                Text(
                                    text = " ms",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(bottom = 3.dp, start = 1.dp)
                                )
                            }

                            Slider(
                                value = cooldownDelay.toFloat(),
                                onValueChange = { viewModel.setCooldownDelay(it.toInt()) },
                                valueRange = 300f..2000f,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .height(24.dp)
                                    .testTag("cooldown_slider"),
                                colors = SliderDefaults.colors(
                                    activeTrackColor = CoralPink,
                                    thumbColor = CoralPink,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                                )
                            )
                        }
                    }
                }
            }

            // 5. Custom Gesture Actions Mapper Setup
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp))
                    .testTag("actions_mapping_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Gesture Actions Mapping",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tailor what action triggers on each swipe or wave.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Swipe Up Mapping Selector
                    GestureMappingSection(
                        gestureLabel = "Swipe Up",
                        description = "Simulates upwards scroll by default",
                        currentSelection = swipeUpMapping,
                        options = listOf("Scroll Up", "Play/Pause", "None"),
                        onSelected = { viewModel.setSwipeUpAction(it) },
                        testTag = "mapping_swipe_up"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Swipe Down Mapping Selector
                    GestureMappingSection(
                        gestureLabel = "Swipe Down",
                        description = "Simulates downwards scroll by default",
                        currentSelection = swipeDownMapping,
                        options = listOf("Scroll Down", "Play/Pause", "None"),
                        onSelected = { viewModel.setSwipeDownAction(it) },
                        testTag = "mapping_swipe_down"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Wave Mapping Selector
                    GestureMappingSection(
                        gestureLabel = "Wave Gesture",
                        description = "Answers calls or plays audio on default",
                        currentSelection = waveMapping,
                        options = listOf("Play/Pause", "Answer Call", "None"),
                        onSelected = { viewModel.setWaveAction(it) },
                        testTag = "mapping_wave"
                    )
                }
            }

            // 6. System Running Statuses indicators
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .border(1.dp, TranslucentWhiteBg, RoundedCornerShape(24.dp))
                    .testTag("services_status_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = TranslucentWhiteBg)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Services Status",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Accessibility Running status indicator
                    ServiceStatusRow(
                        serviceName = "Accessibility Service",
                        isConnected = isAccessibilityConnected,
                        testTag = "accessibility_status"
                    )
                    
                    Spacer(modifier = Modifier.height(10.dp))

                    // Camera analyser Status indicator
                    ServiceStatusRow(
                        serviceName = "Gesturer Cam Analysis Feed",
                        isConnected = isServiceEnabled,
                        testTag = "camera_status"
                    )

                    if (isServiceEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = TranslucentWhiteBg)
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        // Low Light Alert Indicator and FPS counter
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Lighting Conditions",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                            if (isLowLight) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Warning",
                                        tint = CoralPink,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Low Light (Poor Detection)",
                                        color = CoralPink,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.testTag("low_light_alert")
                                    )
                                }
                            } else {
                                Text(
                                    text = "Optimal (${(averageLuminance * 100).toInt()}% Lux)",
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CameraPreviewContainer(
    viewModel: DashboardViewModel,
    opacity: Float,
    sensitivity: Int,
    cooldown: Int
) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    
    // Core camera controller references
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val previewView = remember { PreviewView(context) }

    // Re-instantiate frame analyzer on value updates
    val analyzer = remember(sensitivity, cooldown) {
        GestureAnalyzer(
            onGestureDetected = { gesture ->
                Log.d("DashboardScreen", "Gesture Analyzed in UI: $gesture")
                // Resolve gesture configuration
                val targetAction = when (gesture) {
                    HandGesture.SWIPE_UP -> {
                        val activeAct = viewModel.swipeUpAction.value
                        viewModel.notifyGestureDetected("Swipe Up ➔ $activeAct")
                        activeAct
                    }
                    HandGesture.SWIPE_DOWN -> {
                        val activeAct = viewModel.swipeDownAction.value
                        viewModel.notifyGestureDetected("Swipe Down ➔ $activeAct")
                        activeAct
                    }
                    HandGesture.WAVE -> {
                        val activeAct = viewModel.waveAction.value
                        viewModel.notifyGestureDetected("Wave ➔ $activeAct")
                        activeAct
                    }
                }

                // If Action is NOT NONE, verify if Accessibility Service is running and dispatch globally
                val actionToken = ActionTrigger.fromLabel(targetAction)
                if (actionToken != ActionTrigger.NONE) {
                    if (AirMotionAccessibilityService.isRunning()) {
                        AirMotionAccessibilityService.instance?.handleGesture(gesture)
                    } else {
                        // If Service hasn't bound, fall back to UI toast helper
                        Log.w("DashboardScreen", "Accessibility service is not active/running currently")
                    }
                }
            },
            onMetricsUpdated = { fps, lowLight, avgLum ->
                viewModel.updateMetrics(fps, lowLight, avgLum)
            }
        ).apply {
            this.sensitivity = sensitivity
            this.cooldownMs = cooldown.toLong()
        }
    }

    // Attach CameraX Provider
    LaunchedEffect(key1 = true) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                cameraProvider.unbindAll()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                imageAnalysis.setAnalyzer(cameraExecutor, analyzer)

                // Choose front camera
                val selector = CameraSelector.DEFAULT_FRONT_CAMERA

                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    imageAnalysis
                )
            } catch (e: Exception) {
                Log.e("CameraPreviewContainer", "Failed to bind CameraX configurations", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    // Render Preview View with specific opacity
    AndroidView(
        factory = { previewView },
        modifier = Modifier
            .fillMaxSize()
            .alpha(opacity)
            .testTag("preview_surface")
    )
}

@Composable
fun SilhouettePrivacyView(fps: Int) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF23254A), Color(0xFF131424)),
                )
            )
            .testTag("silhouette_view"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Face,
                contentDescription = "Hidden profile privacy layer active",
                tint = ElectricCyan.copy(alpha = 0.5f),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Privacy Shield Enabled",
                color = ElectricCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = "Face coordinates hidden • $fps FPS capture active",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun GestureMappingSection(
    gestureLabel: String,
    description: String,
    currentSelection: String,
    options: List<String>,
    onSelected: (String) -> Unit,
    testTag: String
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
            .border(1.dp, GrayBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = gestureLabel,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = description,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            Box {
                Button(
                    onClick = { expanded = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onPrimary,
                        contentColor = ElectricCyan
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("${testTag}_menu_button")
                ) {
                    Text(text = currentSelection, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown icon", modifier = Modifier.size(16.dp))
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                ) {
                    options.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(text = opt, color = Color.White, fontSize = 13.sp) },
                            onClick = {
                                onSelected(opt)
                                expanded = false
                            },
                            modifier = Modifier.testTag("${testTag}_item_$opt")
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ServiceStatusRow(
    serviceName: String,
    isConnected: Boolean,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = serviceName,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) SuccessGreen else CoralPink)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isConnected) "Running" else "Stopped",
                color = if (isConnected) SuccessGreen else CoralPink,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.testTag("${testTag}_label")
            )
        }
    }
}
