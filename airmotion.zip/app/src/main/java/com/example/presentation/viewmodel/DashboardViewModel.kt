package com.example.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PreferencesManager
import com.example.service.AirMotionAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesManager = PreferencesManager(application)

    // Bound inputs from Preferences
    val isServiceEnabled = preferencesManager.isServiceEnabled
    val sensitivity = preferencesManager.sensitivity
    val cooldownDelay = preferencesManager.cooldownDelay
    val showPreview = preferencesManager.showPreview
    val previewOpacity = preferencesManager.previewOpacity
    val swipeUpAction = preferencesManager.swipeUpAction
    val swipeDownAction = preferencesManager.swipeDownAction
    val waveAction = preferencesManager.waveAction

    // Live Metrics State from analyzer
    private val _fps = MutableStateFlow(0)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private val _isLowLight = MutableStateFlow(false)
    val isLowLight: StateFlow<Boolean> = _isLowLight.asStateFlow()

    private val _averageLuminance = MutableStateFlow(1.0f)
    val averageLuminance: StateFlow<Float> = _averageLuminance.asStateFlow()

    // Service activity indicators
    private val _isAccessibilityServiceConnected = MutableStateFlow(false)
    val isAccessibilityServiceConnected: StateFlow<Boolean> = _isAccessibilityServiceConnected.asStateFlow()

    private val _lastDetectedGesture = MutableStateFlow<String?>(null)
    val lastDetectedGesture: StateFlow<String?> = _lastDetectedGesture.asStateFlow()

    init {
        checkAccessibilityServiceStatus()
    }

    fun checkAccessibilityServiceStatus() {
        viewModelScope.launch {
            _isAccessibilityServiceConnected.value = AirMotionAccessibilityService.isRunning()
        }
    }

    fun updateMetrics(fpsValue: Int, lowLightEnabled: Boolean, luminance: Float) {
        _fps.value = fpsValue
        _isLowLight.value = lowLightEnabled
        _averageLuminance.value = luminance
    }

    fun notifyGestureDetected(gestureLabel: String) {
        viewModelScope.launch {
            _lastDetectedGesture.value = gestureLabel
            // Clear description after 1.5 seconds flash
            kotlinx.coroutines.delay(1500)
            if (_lastDetectedGesture.value == gestureLabel) {
                _lastDetectedGesture.value = null
            }
        }
    }

    // Mutation functions
    fun setServiceEnabled(enabled: Boolean) {
        preferencesManager.setServiceEnabled(enabled)
    }

    fun setSensitivity(value: Int) {
        preferencesManager.setSensitivity(value)
    }

    fun setCooldownDelay(value: Int) {
        preferencesManager.setCooldownDelay(value)
    }

    fun setShowPreview(show: Boolean) {
        preferencesManager.setShowPreview(show)
    }

    fun setPreviewOpacity(value: Float) {
        preferencesManager.setPreviewOpacity(value)
    }

    fun setSwipeUpAction(action: String) {
        preferencesManager.setSwipeUpAction(action)
    }

    fun setSwipeDownAction(action: String) {
        preferencesManager.setSwipeDownAction(action)
    }

    fun setWaveAction(action: String) {
        preferencesManager.setWaveAction(action)
    }
}
