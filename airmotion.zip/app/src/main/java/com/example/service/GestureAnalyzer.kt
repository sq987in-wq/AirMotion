package com.example.service

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import android.util.Log
import com.example.domain.model.HandGesture
import java.nio.ByteBuffer
import kotlin.math.abs

class GestureAnalyzer(
    private val onGestureDetected: (HandGesture) -> Unit,
    private val onMetricsUpdated: (fps: Int, lowLight: Boolean, avgLuminance: Float) -> Unit
) : ImageAnalysis.Analyzer {

    private val tag = "GestureAnalyzer"
    
    // Configurable Settings (Dynamic updates)
    @Volatile var sensitivity: Int = 75 // 1..100
    @Volatile var cooldownMs: Long = 800

    private var lastTriggerTime: Long = 0
    private var lastFrameTime: Long = 0
    private var frameCount = 0
    private var fpsCalculationTime: Long = 0
    private var currentFps = 0

    // Downsampling Grid (16x16)
    private val gridCols = 16
    private val gridRows = 16
    private var previousGrid: FloatArray? = null

    // Centroid Data Points
    private data class MotionPoint(
        val x: Float,
        val y: Float,
        val timestamp: Long,
        val intensity: Float
    )
    private val motionPoints = ArrayList<MotionPoint>()
    private val motionWindowMs = 600L // Analyze history of 600ms

    override fun analyze(imageProxy: ImageProxy) {
        val currentTime = System.currentTimeMillis()
        if (lastFrameTime == 0L) {
            lastFrameTime = currentTime
            fpsCalculationTime = currentTime
        }

        // Calculate FPS
        frameCount++
        if (currentTime - fpsCalculationTime >= 1000) {
            currentFps = frameCount
            frameCount = 0
            fpsCalculationTime = currentTime
        }

        try {
            val planes = imageProxy.planes
            if (planes.isEmpty()) return

            val yPlane = planes[0]
            val buffer: ByteBuffer = yPlane.buffer
            buffer.rewind()

            val rowStride = yPlane.rowStride
            val pixelStride = yPlane.pixelStride
            val imgWidth = imageProxy.width
            val imgHeight = imageProxy.height

            // Calculate adaptive sampling points for 16x16 grid cell
            val cellWidth = imgWidth / gridCols
            val cellHeight = imgHeight / gridRows
            val currentGrid = FloatArray(gridCols * gridRows)
            var totalBrightness = 0f

            for (r in 0 until gridRows) {
                for (c in 0 until gridCols) {
                    val sampleX = c * cellWidth + cellWidth / 2
                    val sampleY = r * cellHeight + cellHeight / 2
                    val index = sampleY * rowStride + sampleX * pixelStride

                    if (index >= 0 && index < buffer.capacity()) {
                        val pixelValue = (buffer.get(index).toInt() and 0xFF) / 255f
                        currentGrid[r * gridCols + c] = pixelValue
                        totalBrightness += pixelValue
                    }
                }
            }

            val avgLuminance = totalBrightness / (gridCols * gridRows)
            val isLowLight = avgLuminance < 0.20f // Standard threshold for low light

            onMetricsUpdated(currentFps, isLowLight, avgLuminance)

            val prevGrid = previousGrid
            previousGrid = currentGrid

            if (prevGrid != null) {
                // Compute changes
                val diffGrid = FloatArray(gridCols * gridRows)
                var changeSum = 0f
                for (i in diffGrid.indices) {
                    val diff = abs(currentGrid[i] - prevGrid[i])
                    // Only count significant changes to filter out sensor noise
                    diffGrid[i] = if (diff > 0.08f) diff else 0f
                    changeSum += diffGrid[i]
                }

                // Average motion intensity
                val motionIntensity = changeSum / (gridCols * gridRows)

                // Scaling sensitivity threshold: Higher sensitivity -> Lower movement threshold required
                // range of threshold: sensitivity 100 -> 0.01f, sensitivity 1 -> 0.15f
                val detectionThreshold = 0.15f - (sensitivity / 100f) * 0.13f

                if (motionIntensity > detectionThreshold) {
                    // Compute movement centroid coordinates
                    var sumX = 0f
                    var sumY = 0f
                    var sumW = 0f

                    for (r in 0 until gridRows) {
                        for (c in 0 until gridCols) {
                            val w = diffGrid[r * gridCols + c]
                            if (w > 0f) {
                                sumX += c * w
                                sumY += r * w
                                sumW += w
                            }
                        }
                    }

                    if (sumW > 0f) {
                        val centroidX = sumX / sumW / gridCols
                        val centroidY = sumY / sumW / gridRows
                        synchronized(motionPoints) {
                            motionPoints.add(MotionPoint(centroidX, centroidY, currentTime, motionIntensity))
                        }
                    }
                }

                // Process motion history and look for gestures
                processGestureClassification(currentTime)
            }

        } catch (e: Exception) {
            Log.e(tag, "Error analyzing image frame", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun processGestureClassification(currentTime: Long) {
        synchronized(motionPoints) {
            // Clean up points older than our window
            val thresholdTime = currentTime - motionWindowMs
            motionPoints.removeAll { it.timestamp < thresholdTime }

            if (currentTime - lastTriggerTime < cooldownMs) {
                return // In cooldown phase, skip recognition to avoid bouncing
            }

            if (motionPoints.size < 5) return

            // Sort points chronologically
            val points = motionPoints.sortedBy { it.timestamp }

            // Analyze Y movement trend (vertical swipe)
            val minYPoint = points.minByOrNull { it.y } ?: return
            val maxYPoint = points.maxByOrNull { it.y } ?: return
            val minXPoint = points.minByOrNull { it.x } ?: return
            val maxXPoint = points.maxByOrNull { it.x } ?: return

            val deltaY = maxYPoint.y - minYPoint.y
            val deltaX = maxXPoint.x - minXPoint.x
            val duration = points.last().timestamp - points.first().timestamp

            // Require gesture to complete over a logical duration to filter out random motion drops
            if (duration < 150) return

            // Sensitivity scaling for trajectory displacement required:
            // sensitivity 100 -> requires displacement of 0.25, sensitivity 1 -> requires 0.55
            val minDisplacement = 0.55f - (sensitivity / 100f) * 0.30f

            if (deltaY > minDisplacement && deltaY > deltaX) {
                // Determine vertical direction
                if (minYPoint.timestamp < maxYPoint.timestamp) {
                    // Moving from top (smaller y) to bottom (larger y) -> SWIPE_DOWN
                    Log.d(tag, "Detected SWIPE_DOWN (Y delta=$deltaY)")
                    triggerGesture(HandGesture.SWIPE_DOWN, currentTime)
                } else if (maxYPoint.timestamp < minYPoint.timestamp) {
                    // Moving from bottom (larger y) to top (smaller y) -> SWIPE_UP
                    Log.d(tag, "Detected SWIPE_UP (Y delta=$deltaY)")
                    triggerGesture(HandGesture.SWIPE_UP, currentTime)
                }
            } else if (deltaX > minDisplacement && deltaX > deltaY) {
                // If we have strong horizontal progression with oscillation or wave actions, it's a WAVE
                // Measure how much the center alternates directions in X plane
                var directionSwitches = 0
                var lastDir = 0 // -1: Left, 1: Right

                for (i in 1 until points.size) {
                    val dx = points[i].x - points[i - 1].x
                    val currentDir = if (dx > 0.02f) 1 else if (dx < -0.02f) -1 else 0
                    if (currentDir != 0 && lastDir != 0 && currentDir != lastDir) {
                        directionSwitches++
                    }
                    if (currentDir != 0) {
                        lastDir = currentDir
                    }
                }

                // If we either have horizontal direction reversals (waving), or we have a smooth wide hand sweep
                if (directionSwitches >= 1 || deltaX > (minDisplacement * 1.2f)) {
                    Log.d(tag, "Detected WAVE (X delta=$deltaX, switches=$directionSwitches)")
                    triggerGesture(HandGesture.WAVE, currentTime)
                }
            }
        }
    }

    private fun triggerGesture(gesture: HandGesture, currentTime: Long) {
        lastTriggerTime = currentTime
        motionPoints.clear()
        previousGrid = null
        onGestureDetected(gesture)
    }
}
