package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.util.Log
import android.view.KeyEvent
import android.widget.Toast
import com.example.domain.model.HandGesture

class AirMotionAccessibilityService : AccessibilityService() {

    private val tag = "AirMotionService"
    private var isCallRinging = false
    private var phoneStateReceiver: BroadcastReceiver? = null

    companion object {
        @Volatile
        var instance: AirMotionAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(tag, "AirMotion Accessibility Service Connected!")
        registerPhoneStateReceiver()
        showToast("AirMotion Gestures Activated!")
    }

    override fun onInterrupt() {
        Log.d(tag, "AirMotion Accessibility Service Interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        unregisterPhoneStateReceiver()
        showToast("AirMotion Gestures Deactivated")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        unregisterPhoneStateReceiver()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        // We do not require monitoring structural event modifications directly for gestural dispatch
    }

    /**
     * Dispatch gesture events triggered by camera analyzer
     */
    fun handleGesture(gesture: HandGesture) {
        Log.d(tag, "Received global hand gesture trigger: $gesture")
        
        when (gesture) {
            HandGesture.SWIPE_DOWN -> {
                // Scroll down: user hand swiped down. Coordinate literal simulation:
                // Swipe gesture from coordinates (500, 1500) to (500, 500).
                performSwipe(500f, 1500f, 500f, 500f, "Scroll Down")
            }
            HandGesture.SWIPE_UP -> {
                // Scroll up: user hand swiped up. Coordinate literal simulation:
                // Swipe gesture from coordinates (500, 500) to (500, 1500).
                performSwipe(500f, 500f, 500f, 1500f, "Scroll Up")
            }
            HandGesture.WAVE -> {
                if (isCallRinging) {
                    answerIncomingCall()
                } else {
                    toggleMediaPlayback()
                }
            }
        }
    }

    private fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float, actionLabel: String) {
        val path = android.graphics.Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)

        val stroke = GestureDescription.StrokeDescription(path, 50L, 250L)
        val descriptionBuild = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(descriptionBuild, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(tag, "Simulated $actionLabel gesture completed successfully.")
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(tag, "Simulated $actionLabel gesture cancelled by system.")
            }
        }, null)
    }

    private fun toggleMediaPlayback() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val downEvent = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            audioManager.dispatchMediaKeyEvent(downEvent)
            
            val upEvent = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            audioManager.dispatchMediaKeyEvent(upEvent)
            
            Log.d(tag, "Dispatched Toggle Media KeyEvent globally.")
            showToast("Media Play/Pause")
        } catch (e: Exception) {
            Log.e(tag, "Failed to toggle media play/pause", e)
        }
    }

    private fun answerIncomingCall() {
        try {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    telecomManager.acceptRingingCall()
                    Log.d(tag, "Answered incoming telephone call successfully using TelecomManager.")
                    showToast("Call Answered")
                } catch (se: SecurityException) {
                    Log.e(tag, "Security permissions missing for acceptRingingCall. Attempting fallback.", se)
                    // Fallback to simulate a headset hook click to answer phone calls
                    simulateHeadsetHookClick()
                }
            } else {
                simulateHeadsetHookClick()
            }
            isCallRinging = false
        } catch (e: Exception) {
            Log.e(tag, "Critical failure attempting to answer incoming call", e)
            simulateHeadsetHookClick()
        }
    }

    private fun simulateHeadsetHookClick() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val downEvent = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK)
            audioManager.dispatchMediaKeyEvent(downEvent)
            
            val upEvent = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK)
            audioManager.dispatchMediaKeyEvent(upEvent)
            
            Log.d(tag, "Dispatched simulated Headset Hook key events as fallback.")
            showToast("Call Answered (Headset Hook)")
        } catch (e: Exception) {
            Log.e(tag, "Headset Hook simulation failed", e)
        }
    }

    private fun registerPhoneStateReceiver() {
        phoneStateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
                    val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
                    Log.d(tag, "Phone State Transited to: $stateStr")
                    isCallRinging = stateStr == TelephonyManager.EXTRA_STATE_RINGING
                }
            }
        }
        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        registerReceiver(phoneStateReceiver, filter)
    }

    private fun unregisterPhoneStateReceiver() {
        phoneStateReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                // Already unregistered or null
            }
        }
        phoneStateReceiver = null
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }
}
