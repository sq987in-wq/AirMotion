package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isServiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_SERVICE_ENABLED, true))
    val isServiceEnabled: StateFlow<Boolean> = _isServiceEnabled

    private val _sensitivity = MutableStateFlow(prefs.getInt(KEY_SENSITIVITY, 75))
    val sensitivity: StateFlow<Int> = _sensitivity

    private val _cooldownDelay = MutableStateFlow(prefs.getInt(KEY_COOLDOWN, 800))
    val cooldownDelay: StateFlow<Int> = _cooldownDelay

    private val _showPreview = MutableStateFlow(prefs.getBoolean(KEY_SHOW_PREVIEW, true))
    val showPreview: StateFlow<Boolean> = _showPreview

    private val _previewOpacity = MutableStateFlow(prefs.getFloat(KEY_PREVIEW_OPACITY, 0.8f))
    val previewOpacity: StateFlow<Float> = _previewOpacity

    private val _swipeUpAction = MutableStateFlow(prefs.getString(KEY_SWIPE_UP_ACTION, "Scroll Up") ?: "Scroll Up")
    val swipeUpAction: StateFlow<String> = _swipeUpAction

    private val _swipeDownAction = MutableStateFlow(prefs.getString(KEY_SWIPE_DOWN_ACTION, "Scroll Down") ?: "Scroll Down")
    val swipeDownAction: StateFlow<String> = _swipeDownAction

    private val _waveAction = MutableStateFlow(prefs.getString(KEY_WAVE_ACTION, "Play/Pause") ?: "Play/Pause")
    val waveAction: StateFlow<String> = _waveAction

    fun setServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
        _isServiceEnabled.value = enabled
    }

    fun setSensitivity(value: Int) {
        prefs.edit().putInt(KEY_SENSITIVITY, value).apply()
        _sensitivity.value = value
    }

    fun setCooldownDelay(value: Int) {
        prefs.edit().putInt(KEY_COOLDOWN, value).apply()
        _cooldownDelay.value = value
    }

    fun setShowPreview(show: Boolean) {
        prefs.edit().putBoolean(KEY_SHOW_PREVIEW, show).apply()
        _showPreview.value = show
    }

    fun setPreviewOpacity(value: Float) {
        prefs.edit().putFloat(KEY_PREVIEW_OPACITY, value).apply()
        _previewOpacity.value = value
    }

    fun setSwipeUpAction(action: String) {
        prefs.edit().putString(KEY_SWIPE_UP_ACTION, action).apply()
        _swipeUpAction.value = action
    }

    fun setSwipeDownAction(action: String) {
        prefs.edit().putString(KEY_SWIPE_DOWN_ACTION, action).apply()
        _swipeDownAction.value = action
    }

    fun setWaveAction(action: String) {
        prefs.edit().putString(KEY_WAVE_ACTION, action).apply()
        _waveAction.value = action
    }

    companion object {
        private const val PREFS_NAME = "airmotion_prefs"
        private const val KEY_SERVICE_ENABLED = "service_enabled"
        private const val KEY_SENSITIVITY = "sensitivity"
        private const val KEY_COOLDOWN = "cooldown"
        private const val KEY_SHOW_PREVIEW = "show_preview"
        private const val KEY_PREVIEW_OPACITY = "preview_opacity"
        private const val KEY_SWIPE_UP_ACTION = "swipe_up_action"
        private const val KEY_SWIPE_DOWN_ACTION = "swipe_down_action"
        private const val KEY_WAVE_ACTION = "wave_action"
    }
}
